# Memcache Guestbook Sample

This is a sample app for Google App Engine that demonstrates the Memcache Python API.

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/memcache/examples

<!-- end-auto-doc-link -->

Refer to the [App Engine Samples README](../../README.md) for information on how to run and deploy this sample.
ple.
