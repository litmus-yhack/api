import json
import os
import requests
import base64
import urllib
import time

class Spotify():
    # Spotify URLS
    SPOTIFY_AUTH_URL = "https://accounts.spotify.com/authorize"
    SPOTIFY_TOKEN_URL = "https://accounts.spotify.com/api/token"
    SPOTIFY_API_BASE_URL = "https://api.spotify.com"
    API_VERSION = "v1"
    SPOTIFY_API_URL = "{}/{}".format(SPOTIFY_API_BASE_URL, API_VERSION)
    STATE = ""
    SHOW_DIALOG_bool = True
    SHOW_DIALOG_str = str(SHOW_DIALOG_bool).lower()

    #constructor that takes in a token
    def __init__(self, client_id, client_secret, token={}):
        self.CLIENT_ID = client_id
        self.CLIENT_SECRET = client_secret
        #self.CLIENT_SIDE_URL = "https://litmus-app-187901.appspot.com"
        self.CLIENT_SIDE_URL = "http://127.0.0.1:8080"
        self.REDIRECT_URI = "{}/callback/q".format(self.CLIENT_SIDE_URL)
        self.SCOPE = "playlist-modify-public playlist-modify-private"
        self.auth_query_parameters = {
            "response_type": "code",
            "redirect_uri": self.REDIRECT_URI,
            "scope": self.SCOPE,
            "client_id": self.CLIENT_ID
        }

        if token != {}:
            self.response_data = token
            self.refreshToken()

    #makes a post request to get an access token from spotify
    def setAccessToken(self, auth_token):
        global SPOTIFY_TOKEN_URL

        code_payload = {
            "grant_type": "authorization_code",
            "code": str(auth_token),
            "redirect_uri": self.REDIRECT_URI
        }

        base64encoded = base64.b64encode("{}:{}".format(self.CLIENT_ID, self.CLIENT_SECRET))
        headers = {"Authorization": "Basic {}".format(base64encoded)}
        post_request = requests.post(self.SPOTIFY_TOKEN_URL, data=code_payload, headers=headers)

        # Tokens are Returned to Application
        response_data = json.loads(post_request.text)

        # access_token = response_data["access_token"]
        # refresh_token = response_data["refresh_token"]
        # token_type = response_data["token_type"]
        expires_in = response_data["expires_in"]

        response_data["expires_at"] = int(time.time()) + int(expires_in)

        #places token_data into text file
        with open('token_data.txt', 'w') as outfile:
            json.dump(response_data, outfile)

        self.response_data = response_data
        return response_data

    #refreshes the access token if it's expired
    def refreshToken(self):
        if int(self.response_data["expires_at"]) < int(time.time()) + 300:
            payload = { 'refresh_token': self.response_data["refresh_token"],
                           'grant_type': 'refresh_token'}
            base64encoded = base64.b64encode("{}:{}".format(self.CLIENT_ID, self.CLIENT_SECRET))
            headers = {"Authorization": "Basic {}".format(base64encoded)}
            post_request = requests.post(self.SPOTIFY_TOKEN_URL, data=payload, headers=headers)
            response_data = json.loads(post_request.text)
            access_token = response_data["access_token"]
            refresh_token = self.response_data["refresh_token"]
            token_type = response_data["token_type"]
            expires_in = response_data["expires_in"]

            self.response_data["expires_at"] = int(time.time()) + int(expires_in)

            #places token_data into text file
            with open('token_data.txt', 'w') as outfile:
                json.dump(self.response_data, outfile)


    #returns a header using the access token (refreshes it if necessary)
    def getHeader(self):
        if self.response_data["expires_at"] < int(time.time()) + 300:
            self.refreshToken()
        header = {
            "Accept": "application/json",
            "Authorization":"Bearer {}".format(self.response_data["access_token"]),
            "Content-Type": "application/json"
        }
        return header
