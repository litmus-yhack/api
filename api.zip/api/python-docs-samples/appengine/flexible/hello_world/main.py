# Copyright 2015 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# [START app]
import logging, json
from flask import Flask, render_template, request, jsonify, redirect

# shelley sucks
import os
import re
import sys
import subprocess
import requests
import base64
import urllib
import time
import spotify



app = Flask(__name__)
# maps from <string> sid to <dict> data
sid_data = {}



#LITMUS SPOTIFY CREDENTIALS
CLIENT_ID = "d4c533be03d7441cab12bdd6fc6771a7" 
CLIENT_SECRET = "1b37b5484de24791992c39e9f9c8226c"
username = ""
sp = ""
# Server-side Parameters
#CLIENT_SIDE_URL = "https://litmus-app-187901.appspot.com"
CLIENT_SIDE_URL = "http://127.0.0.1:8080"
REDIRECT_URI = "{}/callback/q".format(CLIENT_SIDE_URL)
SCOPE = "playlist-modify-public playlist-modify-private user-top-read user-read-currently-playing user-read-playback-state user-modify-playback-state"

auth_query_parameters = {
    "response_type": "code",
    "redirect_uri": REDIRECT_URI,
    "scope": SCOPE,
    "client_id": CLIENT_ID
}

playlist_id = ""
token_data = {}
played_songs = []
start = 0
on = True
fact = {}
crowd = 0
song = ""
new_song = ""

#removes ascii from a string
def removeNonAscii(s):
    return "".join(filter(lambda x: ord(x)<128, s))

def set_username():
    global username
    view_user = "https://api.spotify.com/v1/me"
    response = requests.get(view_user, headers=sp.getHeader())
    user_data = json.loads(response.text)
    username = user_data["id"]

def create_playlist():
    #create a playlist
    global playlist_id
    playlist_name = 'Litmus Party'
    create_playlist_url = "https://api.spotify.com/v1/users/%s/playlists" % (username)
    playlist_info = {'name': playlist_name, 'public': 'false'}
    response = requests.post(create_playlist_url, data=json.dumps(playlist_info), headers=sp.getHeader())
    playlist_data = json.loads(response.text)
    playlist_id = playlist_data["id"]
    return playlist_id

def add_song(song_id):
    global playlist_id
    spotify_uris = ["spotify:track:%s" % (song_id)]
    add_songs_url = "https://api.spotify.com/v1/users/%s/playlists/%s/tracks"
    response2 = requests.post(add_songs_url % (username, playlist_id), data=json.dumps({"uris": spotify_uris}), headers=sp.getHeader())
    data = json.loads(response2.text)

def factors(crowd):
    crowd = int(crowd)
    data = {}
    if crowd < 5: 
        data["crowd"] = 0
        data["tempo"] = (60, 90)
        data["energy"] = 0.3
    elif crowd < 20:
        data["crowd"] = 10
        data["tempo"] = (90, 120)
        data["energy"] = 0.4
    elif crowd < 50:
        data["crowd"] = 20
        data["tempo"] = (120, 140)
        data["energy"] = 0.7
    elif crowd < 100:
        data["crowd"] = 50
        data["tempo"] = (130, 150)
        data["energy"] = 0.9
    else: 
        data["crowd"] = 100
        data["tempo"] = (160, 190)
        data["energy"] = 1.0
    return data

def current_songs():
    songs = set()
    playlist = "https://api.spotify.com/v1/users/%s/playlists/%s/tracks" % (username, playlist_id)
    response = requests.get(playlist, headers=sp.getHeader())
    playlist_data = json.loads(response.text)

    for song in playlist_data["items"]:
        songs.add(song["track"]["id"])
    return songs

def find_song(data):
    cur_songs = current_songs()
    top_artists_url = "https://api.spotify.com/v1/me/top/%s" % "artists"
    response = requests.get(top_artists_url, headers=sp.getHeader())
    artist_data = json.loads(response.text)
    artists = ""
    count = 0
    for artist in artist_data["items"]: 
        if count > 4:
            break
        else:
            count += 1
            artists += artist["id"] + ","

    QUERY = "https://api.spotify.com/v1/recommendations?min_tempo=%s&seed_artists=%s&limit=20&max_tempo=%s&min_popularity=%s&target_energy=%s" % (data["tempo"][0], artists, data["tempo"][1], 60, data["energy"])
    response = requests.get(QUERY, headers=sp.getHeader())
    data = json.loads(response.text)
    for track in data["tracks"]:
        if not(data["tracks"][0]["id"] in cur_songs):
            return data["tracks"][0]["id"]

def make_request():
    global lyst, on
    if len(lyst) == 0: 
        on = False
    return lyst.pop()

def time_left():
    try:
        user = "https://api.spotify.com/v1/me/player/currently-playing"
        response = requests.get(user, headers=sp.getHeader())
        data = json.loads(response.text)
        duration = int(data["item"]["duration_ms"])
        if bool(data["is_playing"]):
            remaining = int(data["progress_ms"])
            return duration - remaining
        else: 
            return 0
    except ValueError:
        return 0

def delete_song(song_id): 
    delete_playlist_url = "https://api.spotify.com/v1/users/%s/playlists/%s/tracks" % (username, playlist_id)
    json_data = {"tracks": [{"positions": [1],"uri": "spotify:track:%s" % song_id}]}
    response = requests.delete(delete_playlist_url, data=json.dumps(json_data), headers=sp.getHeader())


def get_lit():
    global on, fact, song, crowd, new_song
    set_username()
    create_playlist()
    crowd = 10
    fact = factors(crowd)
    song = find_song(fact)
    add_song(song)
    try:
        play = "https://api.spotify.com/v1/me/player/play"
        response = requests.put(play, headers=sp.getHeader())
        print(response)
    except ValueError:
        pass
    new_song = find_song(factors(crowd))
    new_crowd = crowd
    fact = factors(new_crowd)
    # while(on):
    #     time.sleep(10)
    #     print("check")
    #     new_crowd = make_request()
    #     song_time = time_left()
    #     if song_time < 15000:
    #         print("update")
    #         if song == new_song:
    #             new_song = find_song(factors(new_crowd))
    #             crowd = new_crowd
    #             fact = factors(new_crowd)
    #         song = new_song
    #         add_song(new_song) 
    #     elif not(factors(new_crowd)["crowd"] == fact["crowd"]):
    #         print("change next", song_time)
    #         new_song = find_song(factors(new_crowd))
    #         crowd = new_crowd
    #         fact = factors(new_crowd)

@app.route('/check_song/<sid>', methods = ['POST'])
def check_song_update(sid):
    global on, song, crowd, fact, new_song
    time.sleep(10)
    print("check")
    data = get_sid_data(sid)
    new_crowd = int(data['people'])
    if new_crowd == 0:
        print("Sending people to javascirpt!")
        return jsonify({'people':new_crowd})
    #new_crowd = make_request()
    song_time = time_left()
    if song_time < 15000:
        print("update")
        if song == new_song:
            new_song = find_song(factors(new_crowd))
            crowd = new_crowd
            fact = factors(new_crowd)
        song = new_song
        add_song(new_song) 
    elif not(factors(new_crowd)["crowd"] == fact["crowd"]):
        print("change next", song_time)
        new_song = find_song(factors(new_crowd))
        crowd = new_crowd
        fact = factors(new_crowd)
    ret = {'people':new_crowd}
    print ("Sending people to javascirpt!")
    return jsonify(ret)

# sid_data setter
def set_sid_data(sid, data):
    sid_data[sid] = data

# sid_data getter
def get_sid_data(sid):
    return sid_data[sid]

# sid_data remover
def remove_sid_data(sid):
    del sid_data[sid]

# sid_data 
def sid_data_has(sid):
    return (sid in sid_data)

# panic
def clear_all():
    global on
    sid_data = {}
    on = False

"""
Home Page Handler
"""
@app.route('/')
def home():
    """Return a friendly HTTP greeting."""
    SPOTIFY_AUTH_URL = "https://accounts.spotify.com/authorize"
    url_args = "&".join(["{}={}".format(key,urllib.quote(val)) for key,val in auth_query_parameters.items()])
    auth_url = "{}/?{}".format(SPOTIFY_AUTH_URL, url_args)
    return redirect(auth_url)
    #return render_template('home.html')

"""
Clear All
"""
@app.route('/clearall', methods = ['POST'])
def clear_everything():
    clear_all()

"""
Client Handler : Connect
"""
@app.route('/client/connect', methods = ['POST'])
def client_connect_sid():
    sid = request.form['sid']
    set_sid_data(sid, {'people':0})
    ret = {'sid':sid}
    get_lit()
    return render_template('index.html', sid = sid)

"""
Callback Handler : Connect
"""
@app.route("/callback/q")
def callback():
    # print(auth_token)
    global sp, playlist_id
    auth_token = request.args['code']
    sp = spotify.Spotify(CLIENT_ID, CLIENT_SECRET)
    response = sp.setAccessToken(auth_token)
    #get_lit()
    # embed_url = "https://embed.spotify.com/?uri=spotify%%3Auser%%3A%s%%3Aplaylist%%3A%s" % (username, playlist_id)
    return render_template("home.html")


"""
Client Handler : Disconnect
"""
@app.route('/client/disconnect/<sid>', methods = ['POST'])
def client_disconnect_sid(sid):
    remove_sid_data(sid)
    ret = {'sid':''}
    return jsonify(ret)


"""
Client Handler : Request
"""
@app.route('/client/request/<sid>', methods = ['POST'])
def client_request_people(sid):
    ret = {'sid':sid, 'data':get_sid_data(sid)}
    return jsonify(ret)

"""
Sniffer Handler : Put Data
"""
@app.route('/sniffer/put_data/<sid>', methods = ['POST'])
def sniffer_put_data(sid):
    sniffer_data = request.form.to_dict()

    if sid_data_has(sid):
        set_sid_data(sid, sniffer_data)

    ret = {'data':sniffer_data}
    print(sniffer_data)
    return jsonify(ret)

"""
Sniffer Handler : Check State
"""
@app.route('/sniffer/check_state/<sid>', methods = ['POST'])
def sniffer_check_state(sid):
    ret = {}

    # client is connected
    if sid_data_has(sid):
        ret = {'continue':True}
    # client is disconnected
    else:
        ret = {'continue':False}
    return jsonify(ret)



@app.errorhandler(500)
def server_error(e):
    logging.exception('An error occurred during a request.')
    return """
    An internal error occurred: <pre>{}</pre>
    See logs for full stacktrace.
    """.format(e), 500


if __name__ == '__main__':
    # This is used when running locally. Gunicorn is used to run the
    # application on Google App Engine. See entrypoint in app.yaml.
    app.run(host='127.0.0.1', port=8080, debug=True)
# [END app]
